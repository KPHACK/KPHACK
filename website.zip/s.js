document.addEventListener('DOMContentLoaded', () => {
    const toolBoxes = document.querySelectorAll('.tool-box');

    toolBoxes.forEach(box => {
        box.addEventListener('mouseenter', () => {
            box.style.backgroundColor = '#222222';
        });

        box.addEventListener('mouseleave', () => {
            box.style.backgroundColor = '#111111';
        });

        box.addEventListener('click', () => {
            const command = box.querySelector('.command');
            if (command) {
                navigator.clipboard.writeText(command.textContent)
                    .then(() => {
                        alert('Command copied to clipboard!');
                    })
                    .catch(err => {
                        console.error('Failed to copy command: ', err);
                    });
            }
        });
    });

    // Typing effect for the header
    const header = document.querySelector('h1');
    const text = header.textContent;
    header.textContent = '';
    let i = 0;

    function typeWriter() {
        if (i < text.length) {
            header.textContent += text.charAt(i);
            i++;
            setTimeout(typeWriter, 100);
        }
    }

    typeWriter();
});
