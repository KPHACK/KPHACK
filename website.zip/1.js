const hardwareTools = [
    {
        name: "WiFi Pineapple",
        theory: "Advanced rogue access point and MITM attack platform",
        video: "https://youtu.be/vU8V_2XAvf8?si=c5jpA09bxH0DDmMT"
    },
    {
        name: "Raspberry Pi",
        theory: "Versatile single-board computer for various hacking projects",
        video: "https://youtu.be/hhFyMf7fYqM?si=bmQeaVH7gduZKh15"
    },
    {
        name: "HackRF One",
        theory: "Software-defined radio for analyzing and transmitting radio signals",
        video: "https://youtu.be/YSSnw7655Vg?si=4aaxB-TONKIW3koP"
    },
    {
        name: "USB Rubber Ducky",
        theory: "Keystroke injection tool disguised as a USB drive",
        video: "https://youtu.be/KwoFRIheudo?si=vRdVStOutgYEMTGp"
    },
    {
        name: "Proxmark3",
        theory: "RFID hacking and cloning device",
        video: "https://youtu.be/cU76zmYvzK8?si=0jJ0tzAiNc3gWZjC"
    },
    {
        name: "LAN Turtle",
        theory: "Covert network implant for remote access and data exfiltration",
        video: "https://youtu.be/J7ZpUA9NUe4?si=-8e8l-4BaLt-WNBx"
    },
    {
        name: "Ubertooth One",
        theory: "Open source Bluetooth monitoring and injection platform",
        video: "https://youtu.be/Y9Z5n3SRoOg?si=omn45zByT2BivLym"
    },
    {
        name: "Alfa AWUS036NH",
        theory: "Long-range WiFi adapter for wireless network testing",
        video: "https://youtu.be/hEXwOkyYNL0?si=pLh11sq9Y58hBp_n"
    },
    {
        name: "Packet Squirrel",
        theory: "Stealthy network implant for man-in-the-middle attacks",
        video: "https://youtu.be/hN9tFx5N3uM?si=LmFIcQbvDeM2DpAa"
    },
    {
        name: "Bash Bunny",
        theory: "Multi-purpose USB attack platform",
        video: "https://youtu.be/w_7jAQ_vGoA?si=Wpdv8o9i1iRbdQ9n"
    }
];

function createHardwareBox(tool) {
    const box = document.createElement('div');
    box.className = 'hardware-box';
    box.innerHTML = `
        <alt="${tool.name}">
        <h2>${tool.name}</h2>
        <p>${tool.theory}</p>
        <a href="${tool.video}" target="_blank">Watch Video</a>
    `;
    return box;
}

const container = document.getElementById('hardware-container');
hardwareTools.forEach(tool => {
    container.appendChild(createHardwareBox(tool));
});

