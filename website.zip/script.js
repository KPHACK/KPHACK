document.addEventListener('DOMContentLoaded', () => {
    const skillBoxes = document.querySelectorAll('.skill-box');
    const socialIcons = document.querySelectorAll('.social-icon');

    // Function to generate a random color
    const randomColor = () => {
        return `#${Math.floor(Math.random()*16777215).toString(16)}`;
    };

    // Skill box interactions
    skillBoxes.forEach(box => {
        box.addEventListener('mouseenter', () => {
            const color = randomColor();
            box.style.backgroundColor = color;
            box.style.borderColor = color;
            box.style.color = '#000000';
            box.style.transform = 'scale(1.05)';
            box.style.boxShadow = `0 0 20px ${color}`;
        });

        box.addEventListener('mouseleave', () => {
            box.style.backgroundColor = 'transparent';
            box.style.borderColor = '#00ff00';
            box.style.color = '#ffffff';
            box.style.transform = 'scale(1)';
            box.style.boxShadow = 'none';
        });

        box.addEventListener('click', () => {
            const skill = box.getAttribute('data-skill');
            alert(`You clicked on ${skill}! This could open a modal with more info.`);
        });
    });

    // Social icon interactions
    socialIcons.forEach(icon => {
        icon.addEventListener('mouseenter', () => {
            icon.style.color = randomColor();
            icon.style.animation = 'blink 0.5s infinite';
        });

        icon.addEventListener('mouseleave', () => {
            icon.style.color = '#00ff00';
            icon.style.animation = 'none';
        });
    });

 
    // Smooth scrolling for navigation
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            e.preventDefault();
            document.querySelector(this.getAttribute('href')).scrollIntoView({
                behavior: 'smooth'
            });
        });
    });
});


